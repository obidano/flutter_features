package com.example.odc_flutter_features

import android.content.Intent
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel


class MainActivity : FlutterActivity() {
    val CHANNEL_NAME = "odc.channel"
    var methodChannel: MethodChannel? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        methodChannel = MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            CHANNEL_NAME
        )

        methodChannel!!.setMethodCallHandler { call, result ->
            Log.i("Method Channel", "Methode received ${call.method}");
            if (call.method.equals("fermer_gps")) {
                fermer_gps()
                result.success(true);
                return@setMethodCallHandler
            }

            result.success(null);
        }
    }

    fun fermer_gps() {
        Log.i("GPS FEATURE", "Ouvrir parametre GPS");
        startActivityForResult(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS), 100)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
//        Log.i("RESULT", data?.data.toString());
//        Log.i("RESULT Activity ", Activity.RESULT_OK.toString());
//        Log.i("RESULT requestCode ", requestCode.toString());
        when (requestCode) {
            100 -> {
                Toast.makeText(applicationContext, "Fin processus GPS", Toast.LENGTH_LONG)
                    .show();
                // renvoie d'une reponse à Flutter
                methodChannel?.invokeMethod("fin_gps_fermeture", "")
            }
        }


    }
}
import 'package:flutter/material.dart';

class Consts {
  static Color? DEFAULT_SCAFFOLD_BG = Colors.grey[50];
}

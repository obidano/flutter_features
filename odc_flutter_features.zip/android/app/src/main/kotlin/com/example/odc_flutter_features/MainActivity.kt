package com.example.odc_flutter_features

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
